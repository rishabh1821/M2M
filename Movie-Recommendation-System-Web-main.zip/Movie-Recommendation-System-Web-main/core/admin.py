from django.contrib import admin
from .models import Movie, MovieFilter
# Register your models here.
admin.site.register(Movie)
admin.site.register(MovieFilter)